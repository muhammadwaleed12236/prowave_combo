:HL["/_next/static/css/b7091a2f5e562beb.css","style"]
:HL["/_next/static/css/eb69597bf224cc3a.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"dashboard","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"1loicLugDesxDEdWRSbFS"}
